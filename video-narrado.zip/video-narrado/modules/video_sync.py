"""
Sincronização imagem-áudio e renderização final em MP4 (1920x1080, H.264)
usando FFmpeg via subprocess (sem dependências Python pesadas de vídeo).
"""
import os
import subprocess
from typing import List, Dict

WIDTH, HEIGHT = 1920, 1080
FPS = 25


def _run(cmd: list):
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode != 0:
        raise RuntimeError(
            "Falha no FFmpeg:\n" + proc.stderr.decode(errors="ignore")[-4000:]
        )
    return proc


def _make_image_clip(image_path: str, duration: float, out_path: str):
    """Gera um clipe de vídeo mudo a partir de uma imagem estática."""
    vf = (
        f"scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=decrease,"
        f"pad={WIDTH}:{HEIGHT}:(ow-iw)/2:(oh-ih)/2:color=black,"
        f"setsar=1,fps={FPS}"
    )
    cmd = [
        "ffmpeg", "-y",
        "-loop", "1", "-i", image_path,
        "-t", f"{max(duration, 0.1):.3f}",
        "-vf", vf,
        "-c:v", "libx264", "-pix_fmt", "yuv420p",
        out_path,
    ]
    _run(cmd)


def _make_black_clip(duration: float, out_path: str):
    """Gera um clipe de tela preta para trechos de áudio sem imagem correspondente."""
    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi",
        "-i", f"color=c=black:s={WIDTH}x{HEIGHT}:r={FPS}",
        "-t", f"{max(duration, 0.1):.3f}",
        "-c:v", "libx264", "-pix_fmt", "yuv420p",
        out_path,
    ]
    _run(cmd)


def build_video_clips(timeline: List[Dict], image_paths: List[str], job_dir: str) -> List[str]:
    """
    Cria um clipe de vídeo por trecho da timeline.
    Regra de sincronização: trecho i usa image_paths[i] se existir;
    caso contrário (mais áudio que imagens), usa tela preta.
    """
    clip_paths = []
    for i, seg in enumerate(timeline):
        clip_path = os.path.join(job_dir, f"clip_{i:04d}.mp4")
        if i < len(image_paths):
            _make_image_clip(image_paths[i], seg["duration"], clip_path)
        else:
            _make_black_clip(seg["duration"], clip_path)
        clip_paths.append(clip_path)
    return clip_paths


def concat_video_clips(clip_paths: List[str], job_dir: str) -> str:
    """Concatena os clipes de vídeo (sem áudio) em uma única trilha."""
    list_file = os.path.join(job_dir, "clips.txt")
    with open(list_file, "w") as f:
        for p in clip_paths:
            f.write(f"file '{os.path.abspath(p)}'\n")

    out_path = os.path.join(job_dir, "video_track.mp4")
    cmd = [
        "ffmpeg", "-y",
        "-f", "concat", "-safe", "0", "-i", list_file,
        "-c", "copy",
        out_path,
    ]
    _run(cmd)
    return out_path


def concat_and_normalize_audio(timeline: List[Dict], job_dir: str) -> str:
    """Concatena os .wav de narração e normaliza o volume (evita clipping)."""
    list_file = os.path.join(job_dir, "audio.txt")
    with open(list_file, "w") as f:
        for seg in timeline:
            f.write(f"file '{os.path.abspath(seg['path'])}'\n")

    raw_audio = os.path.join(job_dir, "audio_raw.wav")
    cmd_concat = [
        "ffmpeg", "-y",
        "-f", "concat", "-safe", "0", "-i", list_file,
        "-c", "copy",
        raw_audio,
    ]
    _run(cmd_concat)

    normalized = os.path.join(job_dir, "audio_normalized.wav")
    cmd_norm = [
        "ffmpeg", "-y",
        "-i", raw_audio,
        "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
        normalized,
    ]
    _run(cmd_norm)
    return normalized


def mux_final_video(video_track: str, audio_track: str, out_path: str) -> str:
    """Junta vídeo e áudio normalizado no MP4 final (H.264 + AAC)."""
    cmd = [
        "ffmpeg", "-y",
        "-i", video_track,
        "-i", audio_track,
        "-c:v", "libx264", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest",
        out_path,
    ]
    _run(cmd)
    return out_path


def render(timeline: List[Dict], image_paths: List[str], job_dir: str, final_name="video_final.mp4", progress_cb=None) -> str:
    """Pipeline completo: clipes -> concat vídeo -> concat+normalizar áudio -> mux final."""
    if progress_cb:
        progress_cb("Gerando clipes de imagem/tela preta...")
    clip_paths = build_video_clips(timeline, image_paths, job_dir)

    if progress_cb:
        progress_cb("Concatenando trilha de vídeo...")
    video_track = concat_video_clips(clip_paths, job_dir)

    if progress_cb:
        progress_cb("Concatenando e normalizando áudio...")
    audio_track = concat_and_normalize_audio(timeline, job_dir)

    if progress_cb:
        progress_cb("Renderizando MP4 final (H.264)...")
    out_path = os.path.join(job_dir, final_name)
    mux_final_video(video_track, audio_track, out_path)
    return out_path
