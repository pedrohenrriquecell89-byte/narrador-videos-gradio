"""
Funções utilitárias: validação de entrada e limpeza de temporários.
"""
import os
import shutil
import tempfile
import uuid

MAX_IMAGE_MB = 15
MAX_IMAGES = 200
MAX_SCRIPT_CHARS = 20000
ALLOWED_IMAGE_EXT = {".jpg", ".jpeg", ".png"}


def new_job_dir() -> str:
    """Cria um diretório temporário único para um job de renderização."""
    job_id = uuid.uuid4().hex[:10]
    job_dir = os.path.join(tempfile.gettempdir(), f"job_{job_id}")
    os.makedirs(job_dir, exist_ok=True)
    return job_dir


def cleanup(job_dir: str):
    """Remove o diretório temporário do job após a renderização (ou falha)."""
    try:
        if job_dir and os.path.isdir(job_dir):
            shutil.rmtree(job_dir, ignore_errors=True)
    except Exception:
        pass


def validate_script(script_text: str):
    if not script_text or not script_text.strip():
        raise ValueError("Roteiro vazio. Digite ou cole o texto da narração.")
    if len(script_text) > MAX_SCRIPT_CHARS:
        raise ValueError(
            f"Roteiro muito longo ({len(script_text)} caracteres). "
            f"Limite: {MAX_SCRIPT_CHARS} caracteres por vídeo."
        )
    return True


def validate_images(image_paths: list):
    if not image_paths:
        raise ValueError("Nenhuma imagem enviada.")
    if len(image_paths) > MAX_IMAGES:
        raise ValueError(f"Muitas imagens ({len(image_paths)}). Limite: {MAX_IMAGES}.")
    for p in image_paths:
        ext = os.path.splitext(p)[1].lower()
        if ext not in ALLOWED_IMAGE_EXT:
            raise ValueError(f"Formato não suportado: {ext}. Use JPG ou PNG.")
        size_mb = os.path.getsize(p) / (1024 * 1024)
        if size_mb > MAX_IMAGE_MB:
            raise ValueError(f"Imagem muito grande ({size_mb:.1f}MB). Limite: {MAX_IMAGE_MB}MB.")
    return True


def split_script_into_lines(script_text: str) -> list:
    """
    Divide o roteiro em trechos de narração.
    Regra: cada linha não vazia do texto vira um trecho de áudio,
    sincronizado com uma imagem na mesma ordem de upload.
    """
    lines = [l.strip() for l in script_text.splitlines() if l.strip()]
    if not lines:
        raise ValueError("Não foi possível identificar trechos no roteiro.")
    return lines
