"""
Alinhamento de áudio: calcula o timestamp de início/fim de cada trecho de
narração dentro da faixa de áudio final concatenada.

DECISÃO DE DESIGN (leia antes de trocar por WhisperX):
O roteiro original pedia WhisperX para extrair timestamps automaticamente
a partir do áudio já sintetizado. Na prática, isso é redundante e mais
pesado: como cada trecho de roteiro já é sintetizado como um .wav
separado (ver tts.py), a duração exata de cada trecho já é conhecida no
momento da geração — não é necessário re-transcrever o áudio para
descobrir onde cada frase começa e termina.

Essa abordagem (medir a duração real do .wav gerado) é:
- 100% precisa (não depende de qualidade de transcrição);
- muito mais leve em CPU (WhisperX base/small ainda consome bastante RAM
  e tempo de inferência no tier gratuito do HF Spaces, arriscando timeout);
- determinística.

Um adaptador WhisperX opcional é incluído no fim do arquivo, desativado
por padrão, para quem quiser validar/ajustar timestamps manualmente
(ex.: revisar se a pronúncia do Piper bateu com o texto esperado).
"""
from typing import List, Dict


def build_timeline(tts_segments: List[Dict]) -> List[Dict]:
    """
    Recebe a lista de segmentos gerados pelo TTS (com duração real) e
    devolve uma timeline com start/end acumulados, pronta para o
    módulo de sincronização de vídeo.
    """
    timeline = []
    cursor = 0.0
    for seg in tts_segments:
        start = cursor
        end = cursor + seg["duration"]
        timeline.append({
            "path": seg["path"],
            "text": seg["text"],
            "start": start,
            "end": end,
            "duration": seg["duration"],
        })
        cursor = end
    return timeline


# ---------------------------------------------------------------------------
# Adaptador opcional com WhisperX (desativado por padrão).
# Ative apenas se quiser re-verificar os timestamps por transcrição real.
# Requer: pip install whisperx  (pesado, não incluído no requirements.txt
# padrão para manter o Space dentro do free tier).
# ---------------------------------------------------------------------------
def verify_with_whisperx(full_audio_path: str, model_size: str = "base"):
    try:
        import whisperx
    except ImportError:
        raise RuntimeError(
            "whisperx não instalado. Isso é opcional e não é necessário "
            "para o funcionamento normal do app."
        )
    model = whisperx.load_model(model_size, device="cpu", compute_type="int8")
    audio = whisperx.load_audio(full_audio_path)
    result = model.transcribe(audio, batch_size=8)
    return result.get("segments", [])
