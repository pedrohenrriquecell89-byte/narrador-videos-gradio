"""
Text-to-Speech com Piper (open-source, CPU-only, sem GPU).

Piper precisa de um modelo de voz .onnx + .onnx.json. Modelos são baixados
uma única vez (cache local) a partir do repositório público de vozes Piper
no Hugging Face, que é gratuito e não exige chave de API.
"""
import os
import wave
import requests
from pathlib import Path
from piper.voice import PiperVoice

MODEL_DIR = Path(os.environ.get("PIPER_MODEL_DIR", "./models"))
MODEL_DIR.mkdir(parents=True, exist_ok=True)

# Voz pt_BR leve (rápida em CPU). Pode trocar por pt_BR-faber-medium para
# qualidade maior, ao custo de mais tempo de inferência.
VOICE_NAME = "pt_BR-faber-medium"
BASE_URL = (
    "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/medium"
)
FILES = {
    f"{VOICE_NAME}.onnx": f"{BASE_URL}/{VOICE_NAME}.onnx",
    f"{VOICE_NAME}.onnx.json": f"{BASE_URL}/{VOICE_NAME}.onnx.json",
}

_voice_cache = {"voice": None}


def _download_if_missing():
    for filename, url in FILES.items():
        dest = MODEL_DIR / filename
        if dest.exists():
            continue
        resp = requests.get(url, stream=True, timeout=120)
        resp.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in resp.iter_content(chunk_size=1 << 20):
                f.write(chunk)


def get_voice() -> PiperVoice:
    """Carrega o modelo Piper uma vez e reutiliza (evita recarregar por linha)."""
    if _voice_cache["voice"] is None:
        _download_if_missing()
        model_path = MODEL_DIR / f"{VOICE_NAME}.onnx"
        _voice_cache["voice"] = PiperVoice.load(str(model_path))
    return _voice_cache["voice"]


def synthesize_line(text: str, out_wav_path: str) -> float:
    """
    Gera um arquivo .wav para um único trecho de texto.
    Retorna a duração do áudio gerado, em segundos.
    """
    voice = get_voice()
    with wave.open(out_wav_path, "wb") as wav_file:
        voice.synthesize(text, wav_file)

    with wave.open(out_wav_path, "rb") as wav_file:
        frames = wav_file.getnframes()
        rate = wav_file.getframerate()
        duration = frames / float(rate)
    return duration


def synthesize_script(lines: list, job_dir: str, progress_cb=None) -> list:
    """
    Gera um .wav por trecho de roteiro (sincronização exata: 1 imagem = 1 trecho).
    Retorna lista de dicts: [{"path": ..., "duration": ...}, ...]
    """
    results = []
    for i, line in enumerate(lines):
        wav_path = os.path.join(job_dir, f"line_{i:04d}.wav")
        duration = synthesize_line(line, wav_path)
        results.append({"path": wav_path, "duration": duration, "text": line})
        if progress_cb:
            progress_cb(i + 1, len(lines))
    return results
