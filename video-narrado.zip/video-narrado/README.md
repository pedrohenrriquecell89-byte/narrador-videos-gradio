---
title: Vídeo Narrado Automático
emoji: 🎬
colorFrom: indigo
colorTo: purple
sdk: gradio
sdk_version: 4.44.0
app_file: app.py
pinned: false
---

# 🎬 Vídeo Narrado Automático

App gratuito e open-source para gerar vídeos com narração sincronizada a
partir de um roteiro em texto e uma sequência de fotos. Rodando 100% em
CPU, hospedado gratuitamente no Hugging Face Spaces.

## Estrutura do projeto

```
video-narrado/
├── app.py                      # Interface Gradio + orquestração
├── requirements.txt            # Dependências Python (versões fixadas)
├── packages.txt                # Dependências de sistema (ffmpeg)
├── README.md                   # Este arquivo
└── modules/
    ├── __init__.py
    ├── tts.py                  # Piper TTS (texto -> áudio pt-BR)
    ├── audio_alignment.py      # Timeline de sincronização (start/end)
    ├── video_sync.py           # FFmpeg: clipes, concat, normalização, mux
    └── utils.py                # Validação de entrada e limpeza de temporários
```

## Como funciona (pipeline)

1. **Entrada**: roteiro (uma frase por linha) + fotos em ordem.
2. **TTS (Piper)**: cada linha do roteiro gera um `.wav` separado, em
   português, 100% em CPU.
3. **Sincronização**: como cada trecho já tem duração exata conhecida no
   momento da geração, a timeline (`audio_alignment.py`) é montada
   diretamente pela soma das durações — sem precisar re-transcrever o
   áudio. Ver comentário de design em `audio_alignment.py` sobre por que
   isso substitui o WhisperX com a mesma precisão e bem mais leveza.
4. **Vídeo por trecho**: cada trecho vira um clipe mudo (imagem
   correspondente, ou tela preta se não houver imagem suficiente).
5. **Render final (FFmpeg)**: concatena os clipes de vídeo, concatena e
   normaliza (`loudnorm`) o áudio, e faz o mux final em MP4 1920x1080,
   H.264 + AAC.
6. **Download**: o player de vídeo do Gradio já oferece o botão de
   download do MP4 gerado.

## Deploy no Hugging Face Spaces (passo a passo)

1. **Criar conta**: acesse https://huggingface.co/join e crie uma conta
   gratuita.
2. **Criar novo Space**:
   - Vá em https://huggingface.co/new-space
   - Escolha um nome (ex.: `video-narrado`)
   - SDK: **Gradio**
   - Hardware: **CPU basic (free)**
   - Visibilidade: pública ou privada, como preferir
3. **Enviar os arquivos**: na aba "Files" do Space, faça upload de todos
   os arquivos deste projeto mantendo a estrutura de pastas acima
   (incluindo a subpasta `modules/`). Alternativa via git:
   ```bash
   git clone https://huggingface.co/spaces/SEU_USUARIO/video-narrado
   cd video-narrado
   # copie todos os arquivos deste projeto para dentro da pasta
   git add .
   git commit -m "Deploy inicial"
   git push
   ```
4. **Variáveis de ambiente**: não são obrigatórias. Opcionalmente, defina
   `PIPER_MODEL_DIR` se quiser apontar o cache do modelo de voz para um
   caminho persistente (por padrão usa `./models` dentro do Space).
5. **Build automático**: o Space instala `requirements.txt` e
   `packages.txt` automaticamente e inicia `app.py`. O primeiro
   carregamento baixa o modelo de voz Piper (pt_BR, ~60MB) uma única
   vez — pode levar um ou dois minutos extras na primeira execução.
6. **Link de acesso**: assim que o build terminar, o Space fica
   disponível em `https://huggingface.co/spaces/SEU_USUARIO/video-narrado`.
   Esse link já é mobile-friendly e pode ser compartilhado diretamente.

## Checklist de validação antes de publicar

- [ ] Testar com um roteiro curto (3–4 linhas) e 3–4 imagens JPG/PNG.
- [ ] Confirmar que o vídeo final tem resolução 1920x1080 e áudio audível
      (sem clipping) — pode checar com `ffprobe video_final.mp4`.
- [ ] Testar o caso de **mais texto que imagens** (deve aparecer tela
      preta nos trechos sem foto correspondente).
- [ ] Testar upload direto de câmera pelo celular (Gradio `gr.File`
      aceita captura de câmera no navegador mobile).
- [ ] Testar envio de roteiro vazio ou imagem em formato inválido (deve
      mostrar erro amigável, não travar o app).
- [ ] Verificar que os diretórios temporários (`/tmp/job_*`) não
      acumulam indefinidamente (considerar adicionar um cron simples de
      limpeza se o Space rodar por muito tempo sem reiniciar).
- [ ] Medir tempo total de geração de um vídeo de ~1 minuto — se estiver
      perto do limite de timeout do Space, considerar trocar a voz para
      `pt_BR-faber-low` (mais rápida, qualidade um pouco menor).

## Limitações conhecidas (free tier)

- CPU básico do HF Spaces é compartilhado — vídeos longos (muitos
  minutos de narração) podem demorar vários minutos para renderizar.
- Sem GPU: nenhuma etapa do pipeline depende de CUDA/ONNX-GPU.
- Armazenamento temporário do Space não é persistente entre reinícios —
  isso é esperado e por isso os `job_dir` já são pastas em `/tmp`.
