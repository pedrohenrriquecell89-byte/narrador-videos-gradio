"""
App principal - Automação de edição de vídeo com narração sincronizada.
Stack: Gradio + Piper TTS + FFmpeg. 100% CPU, 100% gratuito/open-source.
"""
import os
import traceback
import gradio as gr

from modules import utils, tts, audio_alignment, video_sync


def gerar_video(roteiro: str, imagens: list, progress=gr.Progress()):
    if not roteiro or not imagens:
        raise gr.Error("Envie o roteiro em texto e pelo menos uma imagem.")

    job_dir = utils.new_job_dir()
    try:
        progress(0.02, desc="Validando entrada...")
        utils.validate_script(roteiro)
        image_paths = [f.name if hasattr(f, "name") else f for f in imagens]
        utils.validate_images(image_paths)
        lines = utils.split_script_into_lines(roteiro)

        progress(0.1, desc="Gerando narração (Piper TTS)...")

        def tts_progress(i, total):
            frac = 0.1 + 0.4 * (i / total)
            progress(frac, desc=f"Narrando trecho {i}/{total}...")

        tts_segments = tts.synthesize_script(lines, job_dir, progress_cb=tts_progress)

        progress(0.5, desc="Calculando sincronização de tempos...")
        timeline = audio_alignment.build_timeline(tts_segments)

        if len(image_paths) < len(timeline):
            gr.Warning(
                f"{len(timeline)} trechos de áudio e apenas {len(image_paths)} "
                f"imagens. Os trechos sem imagem usarão tela preta."
            )

        def render_progress(msg):
            progress(0.6, desc=msg)

        progress(0.6, desc="Renderizando vídeo (pode levar alguns minutos)...")
        final_path = video_sync.render(
            timeline, image_paths, job_dir,
            final_name="video_final.mp4",
            progress_cb=render_progress,
        )

        progress(1.0, desc="Concluído!")
        return final_path

    except Exception as e:
        traceback.print_exc()
        raise gr.Error(f"Erro ao gerar vídeo: {e}")
    # Observação: job_dir não é apagado aqui porque o Gradio ainda precisa
    # ler o arquivo final_path para exibir/baixar. A limpeza acontece na
    # função cleanup_old_jobs() chamada periodicamente (ver abaixo).


CUSTOM_CSS = """
#gerar-btn {font-size: 1.1rem; padding: 14px; border-radius: 12px;}
.gradio-container {max-width: 720px !important; margin: auto;}
"""

with gr.Blocks(css=CUSTOM_CSS, title="Vídeo Narrado Automático") as demo:
    gr.Markdown(
        """
        # 🎬 Vídeo Narrado Automático
        Envie o **roteiro** (uma frase por linha) e as **fotos na ordem certa**.
        O app gera um MP4 pronto para o YouTube, com narração em português
        sincronizada a cada imagem.
        """
    )

    roteiro_input = gr.Textbox(
        label="Roteiro (uma frase/trecho por linha)",
        placeholder="Era uma vez...\nUm lugar muito distante...\nOnde tudo começou...",
        lines=8,
    )

    imagens_input = gr.File(
        label="Fotos (em ordem, JPG ou PNG)",
        file_count="multiple",
        file_types=["image"],
    )

    gerar_btn = gr.Button("🎬 Gerar vídeo", elem_id="gerar-btn", variant="primary")

    video_output = gr.Video(label="Vídeo gerado")

    gerar_btn.click(
        fn=gerar_video,
        inputs=[roteiro_input, imagens_input],
        outputs=[video_output],
    )

    gr.Markdown(
        """
        ---
        **Dicas:**
        - Cada linha do roteiro vira um trecho de narração sincronizado com
          uma imagem, na ordem do upload.
        - Se houver mais linhas de texto que fotos, os trechos restantes
          aparecem com tela preta.
        - Processamento roda em CPU e pode levar alguns minutos — não feche
          a aba enquanto a barra de progresso estiver ativa.
        """
    )

if __name__ == "__main__":
    demo.queue(max_size=10).launch()
